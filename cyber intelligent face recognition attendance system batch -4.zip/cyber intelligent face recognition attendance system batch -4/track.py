import tkinter as tk
from tkinter import Message ,Text
import cv2,os
import shutil
import csv
import numpy as np
from PIL import Image, ImageTk
import pandas as pd
import datetime
import time
import tkinter.ttk as ttk
import tkinter.font as font
from time import sleep

window = tk.Tk()
#helv36 = tk.Font(family='Helvetica', size=36, weight='bold')
window.title("Face_Recogniser")

dialog_title = 'QUIT'
dialog_text = 'Are you sure?'
#answer = messagebox.askquestion(dialog_title, dialog_text)
 
window.geometry('1280x720')
window.configure(background='white')
#window.attributes('-fullscreen', True)

window.grid_rowconfigure(0, weight=1)
window.grid_columnconfigure(0, weight=1)

#path = "profile.jpg"

message = tk.Label(window, text="BT-Face-Recognition-Based-Attendance-Management-System" ,bg="red"  ,fg="white"  ,width=50  ,height=3,font=('times', 30, 'italic bold underline')) 

message.place(x=200, y=20)

lbl3 = tk.Label(window, text="Attendance : ",width=20  ,fg="red"  ,bg="yellow"  ,height=2 ,font=('times', 15, ' bold  underline')) 
lbl3.place(x=400, y=400)

message2 = tk.Label(window, text="" ,fg="red"   ,bg="yellow",activeforeground = "green",width=40  ,height=9  ,font=('times', 15, ' bold ')) 
message2.place(x=700, y=400)

def TrackImages():
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    #recognizer = cv2.face.LBPHFaceRecognizer_create()#cv2.createLBPHFaceRecognizer()
    recognizer.read("TrainingImageLabel\Trainner.yml")
                   # trainer.yml")
    harcascadePath = "haarcascade_frontalface_default.xml"
    faceCascade = cv2.CascadeClassifier(harcascadePath);    
    df=pd.read_csv("StudentDetails\StudentDetails.csv")
    cam = cv2.VideoCapture(0)
    font = cv2.FONT_HERSHEY_SIMPLEX        
    col_names =  ['Id','Name','Date','Time']
    attendance = pd.DataFrame(columns = col_names)
    img_counter = 0
    while True:
        ret, im =cam.read()
        gray=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
        faces=faceCascade.detectMultiScale(gray, 1.2,5)    
        for(x,y,w,h) in faces:
            cv2.rectangle(im,(x,y),(x+w,y+h),(225,0,0),2)
            Id, conf = recognizer.predict(gray[y:y+h,x:x+w])                                   
            if(conf < 50):
                ts = time.time()      
                date = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
                timeStamp = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')
                aa=df.loc[df['ID'] == Id]['Name'].values
                tt=str(Id)+"-"+aa
                attendance.loc[len(attendance)] = [Id,aa,date,timeStamp]
                #noOfFile=len(os.listdir("Imagesknown"))+1
                #cv2.imwrite("Imagesknown\Image"+str(noOfFile) + ".jpg", im[y:y+h,x:x+w])
                #cv2.imwrite("Imagesknown\ "+ + ".jpg", im[y:y+h,x:x+w])
                #img_name = "Imagesknown\Image"+str(noOfFile) + ".jpg".format(img_counter)
                #img_name = "opencv_frame_{}.png".format(img_counter)
                #cv2.imwrite(img_name, im)
                #print("{} written!".format(img_name))
                #img_counter += 1
                
            else:
                Id='Unknown'                
                tt=str(Id)  
            if(conf > 75):
                noOfFile=len(os.listdir("ImagesUnknown"))+1
                #cv2.imwrite("ImagesUnknown\Image"+str(noOfFile) + ".jpg", im[y:y+h,x:x+w])            
            cv2.putText(im,str(tt),(x,y+h), font, 1,(255,255,255),2)        
        attendance=attendance.drop_duplicates(subset=['Id'],keep='first')    
        cv2.imshow('im',im) 
        if (cv2.waitKey(1)==ord('q')):
            break
    
        
        
    ts = time.time()      
    date = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
    timeStamp = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')
    Hour,Minute,Second=timeStamp.split(":")
    fileName="Attendance\Attendance_"+date+"_"+Hour+"-"+Minute+"-"+Second+".csv"
    attendance.to_csv(fileName,index=False)
    ##noOfFile=len(os.listdir("Imagesknown"))+1
    ##cv2.imwrite("Imagesknown\Image"+str(noOfFile) + ".jpg", im[y:y+h,x:x+w])
    #cv2.imwrite("Imagesknown\Image"+conf +"."+Id +'.'+ str(sampleNum) + ".jpg", gray[y:y+h,x:x+w])
    #cv2.imwrite("Imagesknown\Image"+conf +"."+Id +'.'+ str(noOfFile) + ".jpg", gray[y:y+h,x:x+w])
    
    

    #cv2.imwrite("outputImage\ "+name +"."+Id +'.'+ str(sampleNum) + ".jpg", gray[y:y+h,x:x+w])
    cam.release()
    cv2.destroyAllWindows()
    #print(attendance)
    #res=attendance
    #Emessage2.configure(text= res)

trackImg = tk.Button(window, text="Track Images", command=TrackImages  ,fg="red"  ,bg="yellow"  ,width=20  ,height=3, activebackground = "Red" ,font=('times', 15, ' bold '))
trackImg.place(x=400, y=200)
quitWindow = tk.Button(window, text="Quit", command=window.destroy  ,fg="red"  ,bg="yellow"  ,width=30  ,height=3, activebackground = "Red" ,font=('times', 15, ' bold '))
quitWindow.place(x=950, y=200)

window.mainloop()





